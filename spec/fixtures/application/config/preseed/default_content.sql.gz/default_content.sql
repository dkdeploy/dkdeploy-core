SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

BEGIN;
INSERT INTO `preseed_table` VALUES ('1', 'first preseed value');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
