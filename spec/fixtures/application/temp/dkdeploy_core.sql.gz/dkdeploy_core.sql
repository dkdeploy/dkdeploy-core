SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `demo_table`
-- ----------------------------
DROP TABLE IF EXISTS `demo_table`;
CREATE TABLE `demo_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `demo_column` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `demo_table`
-- ----------------------------
BEGIN;
INSERT INTO `demo_table` VALUES ('1', 'content 1'), ('2', 'content 2');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
